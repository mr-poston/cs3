#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

// TODO: Use your struct from Part 1

int main() {
    // TODO: Enter your code below
    //       Make sure you have all 4 includes from above

    return 0;
}