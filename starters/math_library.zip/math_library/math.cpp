#include "math.h"

// Enter your implementation here