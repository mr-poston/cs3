import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;


public class MathSet
{
    // Instance variables


    // Constructors
	

    // Other methods
	public Set<Integer> union()
	{
		return null;
	}

	public Set<Integer> intersection()
	{
		return null;
	}

	public Set<Integer> differenceAMinusB()
	{
		return null;
	}

	public Set<Integer> differenceBMinusA()
	{
		return null;
	}
	
	public Set<Integer> symmetricDifference()
	{		
		return null;
	}	
	
	@Override
    public String toString()
	{
        // Already done! No need to change this
		return "Set one " + one + "\n" +	"Set two " + two +  "\n";
	}

    public static void main(String[] args)
    {
        
    }
}