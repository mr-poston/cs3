#include <iostream>

using namespace std;

// TODO: define your struct here

int main() {
    // TODO: Create 2 or more instructions and print them

    return 0;
}