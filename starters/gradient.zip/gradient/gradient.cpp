#include "util.h"

// TODO: Write a function to create a gradient grid


// TODO: Write a function to print the grid

int main()
{
    // TODO: Get user input


    // TODO: Create a gradient grid


    // TODO: Print the gradient grid
}