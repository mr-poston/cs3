#include <iostream>

using namespace std;

// TODO: encrypt function


// TODO: decrypt function

int main()
{
    // TODO: prompt the user, call appropriate function, print output
    
    return 0;
}