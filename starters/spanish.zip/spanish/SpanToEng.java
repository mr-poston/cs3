import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class SpanToEng
{
    // Instance variable

    // Constructor
    

    public void putEntry(String entry)
    {
        // TODO

    }

    public String translate(String sentence)
    {
        // TODO

        return "";
    }

    @Override
    public String toString()
    {
        return pairs.toString().replaceAll(",", "\n");
    }

    public static void main(String[] args)
    {
        // TODO
        
    }
}