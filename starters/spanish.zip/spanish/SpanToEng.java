// Import statements

public class SpanToEng
{
    // Instance variable

    // Constructor
    

    public void putEntry(String entry)
    {
        // TODO

    }

    public String translate(String sentence)
    {
        // TODO

        return "";
    }

    @Override
    public String toString()
    {
        return pairs.toString().replaceAll(",", "\n");
    }

    public static void main(String[] args)
    {
        // TODO
        
    }
}