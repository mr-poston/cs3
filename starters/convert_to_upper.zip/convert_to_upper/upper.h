#include <string>

using namespace std;

// TODO: Create your upperCase function below
