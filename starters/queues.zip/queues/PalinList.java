// TODO: Imports

public class PalinList
{
    // TODO: Instance variables


    // TODO: Constructors


    // TODO: setList method


    // TODO: isPalin method


    // TODO: toString method


    // TODO: main method
    
}