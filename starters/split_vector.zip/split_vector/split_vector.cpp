#include <iostream>
#include <vector>

using namespace std;

vector<int> initial {8, 3, 9, 5, 14, 11, 23, 2, 6};

int main()
{
    // TODO
    
    return 0;
}