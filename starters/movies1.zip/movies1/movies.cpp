#include <iostream>

using namespace std;

// TODO: Define your movie struct here


movie addMovie();
void listMovies(vector<movie> &movies);

int main()
{
    // TODO: Create a vector of movies
    //       Continue to print the menu and call 
    //           the addMovie or listMovies function
    //           until the user enters `e`
    
    return 0;
}

movie addMovie()
{
    // TODO: Create a movie and return it

}

void listMovies(vector<movie> &movies)
{
    // TODO: Print all of the information about the movies in the vector

}