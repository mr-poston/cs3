// imports TODO

public class Postfix
{
    // Instance variables TODO
    

    // Constructors TODO
    

    // setExpression method TODO
    

    // calc method TODO
    

    // solve method TODO
    

    // toString method TODO
    

    // main method TODO
    
}