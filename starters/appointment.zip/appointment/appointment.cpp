#include <iostream>
#include <vector>

using namespace std;

// TODO: Write your function prototype here

int main()
{
    // TODO
    
    return 0;
}

// TODO: Write your function definition here
