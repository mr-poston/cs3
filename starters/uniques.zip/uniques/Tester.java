/****************************************
 * DO NOT DELETE OR CHANGE THIS FILE!!! *
 ****************************************/

public class Tester {
    public static void main(String[] args) {
        System.out.println(args[0]);
        System.out.println(UniquesDupes.getUniques(args[0]));
        System.out.println(UniquesDupes.getDupes(args[0]));
    }
}
