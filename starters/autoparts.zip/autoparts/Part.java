public class Part implements Comparable<Part>
{
    // Instance variables TODO
    

    // Constructor
    public Part(String line)
    {
        // TODO
    }

    @Override
    public int compareTo(Part other)
    {
        // TODO
    }

    @Override
    public String toString()
    {
        return make + " " + model + " " + year + partNameNumber;
    }
}