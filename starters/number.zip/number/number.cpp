#include "util.h"

int main()
{
    // Comment out the line below to make your program behave randomly.
    // Make sure it is uncommented before you submit or run check50!
    setSeed(1);

    // TODO: Enter your code here
    
    return 0;
}