//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.ArrayList;

public class Player
{
   private ArrayList<Card> hand;
   private int winCount;

   public Player ()
   {
   }

   public Player (int score)
   {
   }

   public void addCardToHand( Card temp )
   {
   }

   public void resetHand( )
   {
   }

   public  void setWinCount( int numwins )
   {
   }

   public int getWinCount() { return 0; }

   public int getHandSize() { return 0; }

   public int getHandValue()
   {
      return 0;
   }

   public  boolean  hit( )
   {
      return false;
   }

   public String toString()
   {
      return "";
   }
}