// Import statements

public class Histogram
{
    // Instance variable

    // Constructors

    public void setSentence(String sentence)
    {
        // TODO

    }

    @Override
    public String toString()
    {
        String output = "";
        output += "char\t1---5----01---5\n";
        // TODO

        return output + "\n";
    }

    // main method
    
}