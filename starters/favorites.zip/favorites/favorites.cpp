#include <iostream>

using namespace std;

int main()
{
    // TODO

    return 0;
}