// TODO: Imports


public class PQTester
{
    // TODO: Instance variable


    // TODO: Constructors


    // TODO: setPQ method


    // TODO: getMin method


    // TODO: getNaturalOrder method


    // TODO: toString mehtod


    // TODO: main method
    
}