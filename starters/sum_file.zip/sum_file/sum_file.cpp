#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    // TODO: Enter your code here
   
    return 0;
}