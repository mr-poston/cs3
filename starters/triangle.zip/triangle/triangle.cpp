#include <iostream>

using namespace std;

// TODO - write your functions here

int main()
{
    // TODO - Get user input and call printTriangle here

    return 0;
}