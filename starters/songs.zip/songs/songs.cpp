#include <iostream>

using namespace std;

// TODO: Define your song struct here


int main()
{
    // TODO: Make and print 2 instances of your song struct
    
    return 0;
}