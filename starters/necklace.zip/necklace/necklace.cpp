#include <iostream>

using namespace std;

int main()
{
    int orig1, orig2;
    cout << "Please enter two digits seperated by a space: ";
    // Notice how we can read two values in one line!
    cin >> orig1 >> orig2;

    // TODO
    
   
    return 0;
}