import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class OddEvenSets {
	// Instance Variables

	
	// Constructors

	
	@Override
	public String toString() {
		return "ODDS : " + odds + "\nEVENS : " + evens + "\n";
	}

	public static void main( String args[] )
	{
				
	}
}