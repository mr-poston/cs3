import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.Stack;

public class SyntaxChecker
{
    // Instance variables TODO
    

    // Constructors TODO
    

    // setExpression TODO
    

    // checkExpression TODO
    

    // toString TODO
    

    // main TODO
    
    
}