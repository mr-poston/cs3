// Import statements


public class Acronyms
{
    // Instance variable
    

    // Constructor
    

    public void putEntry(String entry)
    

    public String convert(String line)
    {
        return "";
    }

    @Override
    public String toString()
    {
        return "";
    }

    public static void main(String[] args)
    {
        
    }
}