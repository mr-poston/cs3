#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;


int main()
{

    // Start with your code from Movies 1
    // Be sure to include the 4 include 
    // statements from above.
    
    return 0;
}