#include <iostream>
#include <bitset>

using namespace std;

// TODO: You should write a function to find the next number


// TODO: You should write a function to find the lowest 12 bits


int main() {
    // TODO: How many checks to perform?

    int emp = 686;
    int com = 1248;
    
    // TODO: Call function(s) and print number of matches

    return 0;
}