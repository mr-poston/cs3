public class Ghost extends Monster {
    public Ghost() {
        // super constructor called automatically
    }

    public Ghost(String name) {
        super(name);
    }
}